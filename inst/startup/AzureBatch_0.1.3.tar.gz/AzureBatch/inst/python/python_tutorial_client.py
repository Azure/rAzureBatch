# python_tutorial_client.py - Batch Python SDK tutorial sample
#
# Copyright (c) Microsoft Corporation
#
# All rights reserved.
#
# MIT License
#
# Permission is hereby granted, free of charge, to any person obtaining a
# copy of this software and associated documentation files (the "Software"),
# to deal in the Software without restriction, including without limitation
# the rights to use, copy, modify, merge, publish, distribute, sublicense,
# and/or sell copies of the Software, and to permit persons to whom the
# Software is furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED *AS IS*, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
# DEALINGS IN THE SOFTWARE.

from __future__ import print_function
import datetime
import os
import sys
import time

try:
    input = raw_input
except NameError:
    pass

import azure.storage.blob as azureblob
import azure.batch.batch_service_client as batch
import azure.batch.batch_auth as batchauth
import azure.batch.models as batchmodels

sys.path.append('.')
sys.path.append('..')
import common.helpers  # noqa

# Update the Batch and Storage account credential strings below with the values
# unique to your accounts. These are used when constructing connection strings
# for the Batch and Storage client objects.
_BATCH_ACCOUNT_NAME = 'prodtest1'
_BATCH_ACCOUNT_KEY = 'xvPlXwaTA/YdNU/0mVg/r/HDTB7BM9M+FhWPLmWRitvFPIMl4d54k73nMxjducHANGBoZVeqpZPm4kbSUS8nHw=='
_BATCH_ACCOUNT_URL = 'https://prodtest1.brazilsouth.batch.azure.com'

_STORAGE_ACCOUNT_NAME = 'batchapppackage'
_STORAGE_ACCOUNT_KEY = 'gdleR94fJIaO5CTsPT2/NvlwIa1XDfDrDHo8U/kTuuXzPeIArTSDuSQeGq5ZnEAFfxX2wp1rNwLWNayjkSohWA=='

_POOL_ID = 'R-Cluster'
# _POOL_NODE_COUNT = 1
# _POOL_VM_SIZE = 'STANDARD_D2_V2'
# _NODE_OS_PUBLISHER = 'microsoft-ads'
# _NODE_OS_OFFER = 'linux-data-science-vm'
# _NODE_OS_SKU = 'linuxdsvm'

_JOB_ID = 'PythonTutorialJob100'


def query_yes_no(question, default="yes"):
    """
    Prompts the user for yes/no input, displaying the specified question text.

    :param str question: The text of the prompt for input.
    :param str default: The default if the user hits <ENTER>. Acceptable values
    are 'yes', 'no', and None.
    :rtype: str
    :return: 'yes' or 'no'
    """
    valid = {'y': 'yes', 'n': 'no'}
    if default is None:
        prompt = ' [y/n] '
    elif default == 'yes':
        prompt = ' [Y/n] '
    elif default == 'no':
        prompt = ' [y/N] '
    else:
        raise ValueError("Invalid default answer: '{}'".format(default))

    while 1:
        choice = input(question + prompt).lower()
        if default and not choice:
            return default
        try:
            return valid[choice[0]]
        except (KeyError, IndexError):
            print("Please respond with 'yes' or 'no' (or 'y' or 'n').\n")

def get_container_sas_token(block_blob_client,
                            container_name, blob_permissions):
    """
    Obtains a shared access signature granting the specified permissions to the
    container.

    :param block_blob_client: A blob service client.
    :type block_blob_client: `azure.storage.blob.BlockBlobService`
    :param str container_name: The name of the Azure Blob storage container.
    :param BlobPermissions blob_permissions:
    :rtype: str
    :return: A SAS token granting the specified permissions to the container.
    """
    # Obtain the SAS token for the container, setting the expiry time and
    # permissions. In this case, no start time is specified, so the shared
    # access signature becomes valid immediately.
    container_sas_token = \
        block_blob_client.generate_container_shared_access_signature(
            container_name,
            permission=blob_permissions,
            expiry=datetime.datetime.utcnow() + datetime.timedelta(hours=2))

    return container_sas_token

def create_job(batch_service_client, job_id, pool_id):
    """
    Creates a job with the specified ID, associated with the specified pool.

    :param batch_service_client: A Batch service client.
    :type batch_service_client: `azure.batch.BatchServiceClient`
    :param str job_id: The ID for the job.
    :param str pool_id: The ID for the pool.
    """
    print('Creating job [{}]...'.format(job_id))

    prep_task_commands = [
        # "wget https://bootstrap.pypa.io/get-pip.py",
        # "python get-pip.py",

        # Edit sudoers file to avoid error:
        # sudo: sorry, you must have a tty to run sudo
        "sed -i -e \"s/Defaults    requiretty.*/ #Defaults    requiretty/g\" /etc/sudoers",

        # Add anaconda to path to use default python and R executables on the node
        # This is done because we're running on the Microsoft ADS image
        "export PATH=/anaconda/envs/py35/bin:$PATH",

        # Debug stuff
        # "echo $PATH ",
        # "which python ",
        # "which pip ",

        # Install required packages
        "sudo env \"PATH=$PATH\" pip install azure-batch",
        "sudo env \"PATH=$PATH\" pip install azure-storage"
    ]

    job_prep_task = batch.models.JobPreparationTask(
        command_line = common.helpers.wrap_commands_in_shell('linux', prep_task_commands),
        run_elevated=True,
        wait_for_success=True
    )

    # on_tasks_complete = batch.models.OnAllTasksComplete(
    #     batch.models.OnAllTasksComplete.terminate_job
    # )

    environment_settings = [batch.models.EnvironmentSetting("myKey", "myVal")]

    job = batch.models.JobAddParameter(
        job_id,
        batch.models.PoolInformation(pool_id=pool_id),
        common_environment_settings=environment_settings,
        job_preparation_task=job_prep_task,
        uses_task_dependencies=True,
        on_all_tasks_complete=batch.models.OnAllTasksComplete.terminate_job)

    try:
        batch_service_client.job.add(job)
    except batchmodels.batch_error.BatchErrorException as err:
        common.helpers.print_batch_exception(err)
        raise

def create_splitter_task(batch_service_client, job_id, application_files, input_file,
              output_container_name, output_container_sas_token):
    """
    Adds a splitter task for the input file to the specified job.

    :param batch_service_client: A Batch service client.
    :type batch_service_client: `azure.batch.BatchServiceClient`
    :param str job_id: The ID of the job to which to add the tasks.
    :param str input_file: Input file to split
    :param output_container_name: The ID of an Azure Blob storage container to
    which the tasks will upload their results.
    :param output_container_sas_token: A SAS token granting write access to
    the specified Azure Blob storage container.
    """

    print('Adding splitter task to job [{}]...'.format(job_id))

    tasks = list()

    command = ["export PATH=/anaconda/envs/py35/bin:$PATH; "
                "python splitter_task.py "
                "--input {} --storageaccount {} "
                "--storagecontainer {} --sastoken \"{}\"".format(
                    input_file,
                    _STORAGE_ACCOUNT_NAME,
                    output_container_name,
                    output_container_sas_token)]

    print("command: " + str(command))

    resource_files = []
    resource_files.extend(application_files)
    resource_files.append(input_file)

    environment_settings = [batch.models.EnvironmentSetting("myKey", "myVal"),
                            batch.models.EnvironmentSetting("PATH", "/anaconda/envs/py35/bin:$PATH")]

    tasks.append(batch.models.TaskAddParameter(
            'splitter_task_level_{}'.format(0),
            common.helpers.wrap_commands_in_shell('linux', command),
            resource_files = resource_files
            # environment_settings=environment_settings
            )
    )

    batch_service_client.task.add_collection(job_id, tasks)


def wait_for_tasks_to_complete(batch_service_client, job_id, timeout):
    """
    Returns when all tasks in the specified job reach the Completed state.

    :param batch_service_client: A Batch service client.
    :type batch_service_client: `azure.batch.BatchServiceClient`
    :param str job_id: The id of the job whose tasks should be to monitored.
    :param timedelta timeout: The duration to wait for task completion. If all
    tasks in the specified job do not reach Completed state within this time
    period, an exception will be raised.
    """
    timeout_expiration = datetime.datetime.now() + timeout

    print("Monitoring all tasks for 'Completed' state, timeout in {}..."
          .format(timeout), end='')

    while datetime.datetime.now() < timeout_expiration:
        print('.', end='')
        sys.stdout.flush()
        tasks = batch_service_client.task.list(job_id)

        incomplete_tasks = [task for task in tasks if
                            task.state != batchmodels.TaskState.completed]
        if not incomplete_tasks:
            print()
            return True
        else:
            time.sleep(1)

    print()
    raise RuntimeError("ERROR: Tasks did not reach 'Completed' state within "
                       "timeout period of " + str(timeout))


def download_blobs_from_container(block_blob_client,
                                  container_name, directory_path):
    """
    Downloads all blobs from the specified Azure Blob storage container.

    :param block_blob_client: A blob service client.
    :type block_blob_client: `azure.storage.blob.BlockBlobService`
    :param container_name: The Azure Blob storage container from which to
     download files.
    :param directory_path: The local directory to which to download the files.
    """
    print('Downloading all files from container [{}]...'.format(
        container_name))

    container_blobs = block_blob_client.list_blobs(container_name)

    for blob in container_blobs.items:
        destination_file_path = os.path.join(directory_path, blob.name)

        block_blob_client.get_blob_to_path(container_name,
                                           blob.name,
                                           destination_file_path)

        print('  Downloaded blob [{}] from container [{}] to {}'.format(
            blob.name,
            container_name,
            destination_file_path))

    print('  Download complete!')


if __name__ == '__main__':

    start_time = datetime.datetime.now().replace(microsecond=0)
    print('Sample start: {}'.format(start_time))
    print()

    # Create the blob client, for use in obtaining references to
    # blob storage containers and uploading files to containers.
    blob_client = azureblob.BlockBlobService(
        account_name=_STORAGE_ACCOUNT_NAME,
        account_key=_STORAGE_ACCOUNT_KEY)

    # Use the blob client to create the containers in Azure Storage if they
    # don't yet exist.
    app_container_name = _JOB_ID.lower() + '-application'
    input_container_name = _JOB_ID.lower() + '-input'
    output_container_name = _JOB_ID.lower() + '-output'
    blob_client.create_container(app_container_name, fail_on_exist=False)
    blob_client.create_container(input_container_name, fail_on_exist=False)
    blob_client.create_container(output_container_name, fail_on_exist=False)

    # Paths to the task script. This script will be executed by the tasks that
    # run on the compute nodes.
    application_file_paths = ['python_tutorial_task.py',
                                'common/__init__.py',
                                'common/helpers.py',
                                'splitter_task.py',
                                'worker_task.py',
                                'merger_task.py']

    # The collection of data files that are to be processed by the tasks.
    input_file_paths = [os.path.realpath('./data/taskdata1.txt'),
                        os.path.realpath('./data/taskdata2.txt'),
                        os.path.realpath('./data/taskdata3.txt')]

    # Upload the application script to Azure Storage. This is the script that
    # will process the data files, and is executed by each of the tasks on the
    # compute nodes.
    application_files = [
        common.helpers.upload_file_to_container(blob_client, app_container_name, os.path.realpath(file_path), file_path)
        for file_path in application_file_paths]

    # Upload the data files. This is the data that will be processed by each of
    # the tasks executed on the compute nodes in the pool.
    input_files = [
        common.helpers.upload_file_to_container(blob_client, input_container_name, file_path)
        for file_path in input_file_paths]

    # Obtain a shared access signature that provides write access to the output
    # container to which the tasks will upload their output.
    output_container_sas_token = get_container_sas_token(
        blob_client,
        output_container_name,
        azureblob.BlobPermissions.WRITE)

    # Create a Batch service client. We'll now be interacting with the Batch
    # service in addition to Storage
    credentials = batchauth.SharedKeyCredentials(_BATCH_ACCOUNT_NAME,
                                                 _BATCH_ACCOUNT_KEY)

    batch_client = batch.BatchServiceClient(
        credentials,
        base_url=_BATCH_ACCOUNT_URL)

    # Create the pool that will contain the compute nodes that will execute the
    # tasks. The resource files we pass in are used for configuring the pool's
    # start task, which is executed each time a node first joins the pool (or
    # is rebooted or re-imaged).
    # create_pool(batch_client,
    #             _POOL_ID,
    #             application_files,
    #             _NODE_OS_PUBLISHER,
    #             _NODE_OS_OFFER,
    #             _NODE_OS_SKU)

    # Create the job that will run the tasks.
    create_job(batch_client, _JOB_ID, _POOL_ID)

    # Add the tasks to the job. We need to supply a container shared access
    # signature (SAS) token for the tasks so that they can upload their output
    # to Azure Storage.
    create_splitter_task(batch_client,
              _JOB_ID,
              application_files,
              input_files[0],
              output_container_name,
              output_container_sas_token)

    # Pause execution until tasks reach Completed state.
    wait_for_tasks_to_complete(batch_client,
                               _JOB_ID,
                               datetime.timedelta(minutes=20))

    print("  Success! All tasks reached the 'Completed' state within the "
          "specified timeout period.")

    # Download the task output files from the output Storage container to a
    # local directory
    download_blobs_from_container(blob_client,
                                  output_container_name,
                                  os.path.expanduser('~'))

    # Clean up storage resources
    print('Deleting containers...')
    blob_client.delete_container(app_container_name)
    blob_client.delete_container(input_container_name)
    blob_client.delete_container(output_container_name)

    # Print out some timing info
    end_time = datetime.datetime.now().replace(microsecond=0)
    print()
    print('Sample end: {}'.format(end_time))
    print('Elapsed time: {}'.format(end_time - start_time))
    print()

    # Clean up Batch resources (if the user so chooses).
    if query_yes_no('Delete job?') == 'yes':
        batch_client.job.delete(_JOB_ID)

    # if query_yes_no('Delete pool?') == 'yes':
    #     batch_client.pool.delete(_POOL_ID)

    print()
    input('Press ENTER to exit...')
