if __name__ == '__main__':
    
    print("Hello. I am your worker task. Eventually I will do something useful")
    print("Download required inputs")
    print("Run R model on input")
    print("Upload results to intermidate directory")