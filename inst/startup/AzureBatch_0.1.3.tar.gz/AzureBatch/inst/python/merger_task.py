if __name__ == '__main__':
    
    print("Hello. I am your merger task. Eventually I will do something useful")
    print("Download all files from intermediate directory")
    print("Merge them")
    print("Upload final result output")
    print("If we need to, start splitter task again")