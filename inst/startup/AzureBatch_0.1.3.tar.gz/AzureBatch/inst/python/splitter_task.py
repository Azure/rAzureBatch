# python_tutorial_client.py - Batch Python SDK tutorial sample
#
# Copyright (c) Microsoft Corporation
#
# All rights reserved.
#
# MIT License
#
# Permission is hereby granted, free of charge, to any person obtaining a
# copy of this software and associated documentation files (the "Software"),
# to deal in the Software without restriction, including without limitation
# the rights to use, copy, modify, merge, publish, distribute, sublicense,
# and/or sell copies of the Software, and to permit persons to whom the
# Software is furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED *AS IS*, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
# DEALINGS IN THE SOFTWARE.

from __future__ import print_function
import datetime
import os
import sys
import time

try:
    input = raw_input
except NameError:
    pass

import azure.storage.blob as azureblob
import azure.batch.batch_service_client as batch
import azure.batch.batch_auth as batchauth
import azure.batch.models as batchmodels

sys.path.append('.')
sys.path.append('..')
import common.helpers  # noqa

# Update the Batch and Storage account credential strings below with the values
# unique to your accounts. These are used when constructing connection strings
# for the Batch and Storage client objects.
_BATCH_ACCOUNT_NAME = 'prodtest1'
_BATCH_ACCOUNT_KEY = 'xvPlXwaTA/YdNU/0mVg/r/HDTB7BM9M+FhWPLmWRitvFPIMl4d54k73nMxjducHANGBoZVeqpZPm4kbSUS8nHw=='
_BATCH_ACCOUNT_URL = 'https://prodtest1.brazilsouth.batch.azure.com'

_STORAGE_ACCOUNT_NAME = 'batchapppackage'
_STORAGE_ACCOUNT_KEY = 'gdleR94fJIaO5CTsPT2/NvlwIa1XDfDrDHo8U/kTuuXzPeIArTSDuSQeGq5ZnEAFfxX2wp1rNwLWNayjkSohWA=='

_JOB_ID = 'PythonTutorialJob'

def add_tasks(batch_service_client, job_id, application_files, input_files,
              output_container_name, output_container_sas_token):
    """
    Adds a task for each input file in the collection to the specified job.

    :param batch_service_client: A Batch service client.
    :type batch_service_client: `azure.batch.BatchServiceClient`
    :param str job_id: The ID of the job to which to add the tasks.
    :param list input_files: A collection of input files. One task will be
     created for each input file.
    :param output_container_name: The ID of an Azure Blob storage container to
    which the tasks will upload their results.
    :param output_container_sas_token: A SAS token granting write access to
    the specified Azure Blob storage container.
    """

    print('Adding {} tasks to job [{}]...'.format(len(input_files), job_id))

    tasks = list()

    for idx, input_file in enumerate(input_files):

        # command = ['python $AZ_BATCH_NODE_SHARED_DIR/python_tutorial_task.py '
        #            '--filepath {} --numwords {} --storageaccount {} '
        #            '--storagecontainer {} --sastoken "{}"'.format(
        #                input_file.file_path,
        #                '3',
        #                _STORAGE_ACCOUNT_NAME,
        #                output_container_name,
        #                output_container_sas_token)]

        command = ['python python_tutorial_task.py '
                   '--filepath {} --numwords {} --storageaccount {} '
                   '--storagecontainer {} --sastoken "{}"'.format(
                       input_file.file_path,
                       '3',
                       _STORAGE_ACCOUNT_NAME,
                       output_container_name,
                       output_container_sas_token)]

        resource_files = []
        resource_files.extend(application_files)
        resource_files.append(input_file)
        tasks.append(batch.models.TaskAddParameter(
                'topNtask{}'.format(idx),
                common.helpers.wrap_commands_in_shell('linux', command),
                resource_files = resource_files
                )
        )

    batch_service_client.task.add_collection(job_id, tasks)

if __name__ == '__main__':

    print("Hello. I am your splitter task. Eventually I will do something useful")
    print("Run R script to split data")
    print("for each chunk")
    print("  upload file to storage")
    print("  create a worker task to process the chunk")
    print("Create a merge task, with a dependency on each worker task")

    # parser = argparse.ArgumentParser()
    # parser.add_argument('--filepath', required=True,
    #                     help='The path to the text file to process. The path'
    #                          'may include a compute node\'s environment'
    #                          'variables, such as'
    #                          '$AZ_BATCH_NODE_SHARED_DIR/filename.txt')
    # parser.add_argument('--numwords', type=int, required=True,
    #                     help='The number of words to print top frequency.')
    # parser.add_argument('--storageaccount', required=True,
    #                     help='The name the Azure Storage account that owns the'
    #                          'blob storage container to which to upload'
    #                          'results.')
    # parser.add_argument('--storagecontainer', required=True,
    #                     help='The Azure Blob storage container to which to'
    #                          'upload results.')
    # parser.add_argument('--sastoken', required=True,
    #                     help='The SAS token providing write access to the'
    #                          'Storage container.')
    # args = parser.parse_args()

    # input_file = os.path.realpath(args.filepath)
    # output_file = '{}_OUTPUT{}'.format(
    #     os.path.splitext(args.filepath)[0],
    #     os.path.splitext(args.filepath)[1])

    # with open(input_file) as f:
    #     words = [word.strip(string.punctuation) for word in f.read().split()]

    # word_counts = collections.Counter(words)
    # with open(output_file, "w") as text_file:
    #     print('Word\tCount', file=text_file)
    #     print("------------------------------", file=text_file)
    #     for word, count in word_counts.most_common(args.numwords):
    #         print(word + ':\t' + str(count), file=text_file)
    #     print("------------------------------", file=text_file)
    #     print("Node: " + os.environ['AZ_BATCH_NODE_ID'], file=text_file)
    #     print("Task: " + os.environ['AZ_BATCH_TASK_ID'], file=text_file)
    #     print("Job:  " + os.environ['AZ_BATCH_JOB_ID'], file=text_file)
    #     print("Pool: " + os.environ['AZ_BATCH_POOL_ID'], file=text_file)

    # Create the blob client using the container's SAS token.
    # This allows us to create a client that provides write
    # access only to the container.
    # blob_client = azureblob.BlockBlobService(account_name=args.storageaccount,
    #                                          sas_token=args.sastoken)

    # output_file_path = os.path.realpath(output_file)

    # print('Uploading file {} to container [{}]...'.format(
    #     output_file_path,
    #     args.storagecontainer))

    # blob_client.create_blob_from_path(args.storagecontainer,
    #                                   output_file,
    #                                   output_file_path)

    # start_time = datetime.datetime.now().replace(microsecond=0)
    # print('Sample start: {}'.format(start_time))
    # print()

    # # Create the blob client, for use in obtaining references to
    # # blob storage containers and uploading files to containers.
    # blob_client = azureblob.BlockBlobService(
    #     account_name=_STORAGE_ACCOUNT_NAME,
    #     account_key=_STORAGE_ACCOUNT_KEY)

    # # Use the blob client to create the containers in Azure Storage if they
    # # don't yet exist.
    # app_container_name = _JOB_ID + '_application'
    # input_container_name = _JOB_ID + '_input'
    # output_container_name = _JOB_ID + '_output'
    # blob_client.create_container(app_container_name, fail_on_exist=False)
    # blob_client.create_container(input_container_name, fail_on_exist=False)
    # blob_client.create_container(output_container_name, fail_on_exist=False)


    # # The input file should be downloaded as an resource file to the task
    # # Split the file and create 1 task for each chunk
    # # Finally create a merged task which will merge the output which is dependent on all worker tasks


    # # Paths to the task script. This script will be executed by the tasks that
    # # run on the compute nodes.
    # application_file_paths = [os.path.realpath('python_tutorial_task.py')]

    # # The collection of data files that are to be processed by the tasks.
    # input_file_paths = [os.path.realpath('./data/taskdata1.txt'),
    #                     os.path.realpath('./data/taskdata2.txt'),
    #                     os.path.realpath('./data/taskdata3.txt')]

    # # Upload the application script to Azure Storage. This is the script that
    # # will process the data files, and is executed by each of the tasks on the
    # # compute nodes.
    # application_files = [
    #     upload_file_to_container(blob_client, app_container_name, file_path)
    #     for file_path in application_file_paths]

    # # Upload the data files. This is the data that will be processed by each of
    # # the tasks executed on the compute nodes in the pool.
    # input_files = [
    #     upload_file_to_container(blob_client, input_container_name, file_path)
    #     for file_path in input_file_paths]

    # # Obtain a shared access signature that provides write access to the output
    # # container to which the tasks will upload their output.
    # output_container_sas_token = get_container_sas_token(
    #     blob_client,
    #     output_container_name,
    #     azureblob.BlobPermissions.WRITE)

    # # Create a Batch service client. We'll now be interacting with the Batch
    # # service in addition to Storage
    # credentials = batchauth.SharedKeyCredentials(_BATCH_ACCOUNT_NAME,
    #                                              _BATCH_ACCOUNT_KEY)

    # batch_client = batch.BatchServiceClient(
    #     credentials,
    #     base_url=_BATCH_ACCOUNT_URL)

    

    # # Add the tasks to the job. We need to supply a container shared access
    # # signature (SAS) token for the tasks so that they can upload their output
    # # to Azure Storage.
    # add_tasks(batch_client,
    #           _JOB_ID,
    #           application_files,
    #           input_files,
    #           output_container_name,
    #           output_container_sas_token)

    # # Pause execution until tasks reach Completed state.
    # wait_for_tasks_to_complete(batch_client,
    #                            _JOB_ID,
    #                            datetime.timedelta(minutes=20))

    # print("  Success! All tasks reached the 'Completed' state within the "
    #       "specified timeout period.")

    # # Download the task output files from the output Storage container to a
    # # local directory
    # download_blobs_from_container(blob_client,
    #                               output_container_name,
    #                               os.path.expanduser('~'))

    # # Clean up storage resources
    # print('Deleting containers...')
    # blob_client.delete_container(app_container_name)
    # blob_client.delete_container(input_container_name)
    # blob_client.delete_container(output_container_name)

    # # Print out some timing info
    # end_time = datetime.datetime.now().replace(microsecond=0)
    # print()
    # print('Sample end: {}'.format(end_time))
    # print('Elapsed time: {}'.format(end_time - start_time))
    # print()

    # # Clean up Batch resources (if the user so chooses).
    # if query_yes_no('Delete job?') == 'yes':
    #     batch_client.job.delete(_JOB_ID)

    # if query_yes_no('Delete pool?') == 'yes':
    #     batch_client.pool.delete(_POOL_ID)

    # print()
    # input('Press ENTER to exit...')
