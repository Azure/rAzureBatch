getInstallationCommand <- function(packages){
  installation <- ""

  for(package in packages){
    installation <- paste0(installation,
                           sprintf(" R -e \'install.packages(\\\"%s\\\", dependencies=TRUE)\'", package),
                           ";")
  }

  installation <- substr(installation, 1, nchar(installation) - 1)
}

getGithubInstallationCommand <- function(packages){
  installation <- ""
  installation <- paste0(installation,
                         sprintf(" R -e \'install.packages(\"%s\", dependencies=TRUE)\'", "devtools"),
                         ";")

  if(length(packages) != 0){
      for(package in packages){
        installation <- paste0(installation,
                              sprintf(" R -e \'library(\"%s\"); install_github(\"%s\")\'", "devtools", package),
                              ";")
      }
  }


  installation <- substr(installation, 1, nchar(installation) - 1)
}

getInstallationCommand <- function(packages){
  #installation <- sprintf("Rscript --vanilla --verbose  %s/install.R %s", workingDir, mode)
  # for(package in packages){
  #   installation <- paste0(installation,
  #                          sprintf(" R -e \'install.packages(\\\"%s\\\", dependencies=TRUE)\'", package),
  #                          ";")
  # }
  #temp <- paste(packages)
  #temp <- paste0(packages, collapse = " ")
  #installation <- sprintf("%s %s", installation, temp)

  installation = ""

  for(package in packages){
      installation <- paste0(installation,
                             sprintf(" R -e \'install.packages(\\\"%s\\\", dependencies=TRUE)\'", package),
                             ";")
  }

  # TODO: get github installation to work
  # if(length(config$batchAccount$rPackages$github) != 0){
  #   github <- "library(devtools);"
  #   for(package in config$batchAccount$rPackages$github){
  #     installation <- paste0(installation,
  #                           sprintf(" R -e \'library(\\\"devtools\\\"); install_github(\\\"%s\\\")\'", package),
  #                           ";")
  #   }
  # }

  installation <- substr(installation, 1, nchar(installation) - 1)
}

linuxWrapCommands <- function(commands = c()){
  commandLine <- sprintf("/bin/bash -c \"set -e; set -o pipefail; %s wait\"", paste0(paste(commands, sep = " ", collapse = "; "),"; "))
}
