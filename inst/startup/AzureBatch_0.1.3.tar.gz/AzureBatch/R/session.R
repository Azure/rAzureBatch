az_create_config_default <- function(){
  if(!file.exists(paste0(getwd(), "/", "az_config.json"))){
    config <- list(batchName = "<BATCH_ACCOUNT_NAME>",
                   batchKey = "<BATCH_KEY>",
                   batchUrl = "<BATCH_URL>",
                   storageName = "<STORAGE_ACCOUNT_NAME>",
                   storageKey = "<STORAGE_ACCOUNT_KEY>",
                   data = "",

                   vmSize = "STANDARD_A1",
                   numberOfNodes = 3,
                   packages = "",
                   rootDirectory = getwd(),
                   verbose = FALSE)

    configJson <- jsonlite::toJSON(config, auto_unbox = TRUE, pretty = TRUE)
    write(configJson, file=paste0(config$rootDirectory, "/", "az_config.json"))

    print(sprintf("A config file has been generated %s, please fill in your Azure Batch and Azure Storage credentials",
                  paste0(getwd(), "/", "az_config.json")))
  }
  else{
    print(sprintf("A config file already exists at %s", paste0(config$rootDirectory, "/", "az_config.json")))
  }
}

az_create_config <- function(batchName, batchKey, batchUrl, storageName = "", storageKey = "", data = "", packages = ""){
  if(!file.exists(paste0(getwd(), "/", "az_config.json"))){
    config <- list(batchName = batchName,
                   batchKey = batchKey,
                   batchUrl = batchUrl,
                   storageName = storageName,
                   storageKey = storageKey,
                   data = data,

                   vmSize = "STANDARD_A1",
                   numberOfNodes = 3,
                   packages = packages,
                   rootDirectory = getwd(),
                   verbose = FALSE)

    configJson <- jsonlite::toJSON(config, auto_unbox = TRUE, pretty = TRUE)
    write(configJson, file=paste0(config$rootDirectory, "/", "az_config.json"))

    print(sprintf("A config file has been generated %s", paste0(config$rootDirectory, "/", "az_config.json")))
  }
}

az_start_session <- function(){
  config <- get_configuration_file()
  credentials <- get_batch_credentials()

  timeNow <- Sys.time()
  requestDate <- format(timeNow, "%Y%b%d%H%M%S", tz="GMT")

  id <-  sprintf("%s-%s-%s",
                 "pysduck",
                 credentials$name,
                 format(timeNow, "%Y%m%d%H%M%S", tz="GMT"))

  create_container(id)

  if(config$data != c("")){
    for(i in length(config$data)){
      upload_data(containerName = id, config$data[i])
    }
  }

  headers <- c()
  headers['Content-Type'] <- 'application/json;odata=minimalmetadata'

  commands <- c("cd /",
                "cd etc/R",
                "echo \"options(repos = list(CRAN=\\\"http://cran.us.r-project.org/\\\"))\" >> Rprofile.site",
                "dpkg -L r-cran-littler")

  body = list(vmSize = config$vmSize,
              id = id,
              targetDedicated = config$numberOfNodes,
              startTask = list(
                commandLine = linux_wrap_commands(commands),
                runElevated = TRUE,
                waitForSuccess = TRUE,
                environmentSettings = list(list(
                  name = "REPOS",
                  value ="http://cran.us.r-project.org"))
              ),
              virtualMachineConfiguration=list(imageReference=list(publisher="microsoft-ads",
                                                                   offer="linux-data-science-vm",
                                                                   sku="linuxdsvm",
                                                                   version="latest"),
                                               nodeAgentSKUId="batch.node.centos 7"))

  size <- nchar(jsonlite::toJSON(body, method="C", auto_unbox = TRUE))
  headers['Content-Length'] <- size

  request <- AzureRequest$new(
    method = "POST",
    path = "/pools",
    query = list("api-version" = apiVersion),
    headers = headers
  )

  CallBatchService(request, credentials, body)

  commands <- c("cd /",
                "cd usr/lib/R/site-library/littler/examples",
                "export REPOS=http://cran.us.r-project.org",
                get_installation_command())

  body = list(id=id,
              poolInfo=list("poolId"=id),
              jobPreparationTask = list(
                commandLine = linux_wrap_commands(commands),
                runElevated = TRUE,
                environmentSettings = list(list(
                  name = "REPOS",
                  value="http://cran.us.r-project.org"))
              ))

  size <- nchar(jsonlite::toJSON(body, method="C", auto_unbox = TRUE))

  headers['Content-Length'] <- size

  request <- AzureRequest$new(
    method = "POST",
    path = "/jobs",
    query = list("api-version" = apiVersion),
    headers = headers
  )

  CallBatchService(request, credentials, body)

  configJson <- NULL
  if(!file.exists(".session.json")){
    body <- list(sessionIds = jsonlite::unbox( c(id)), containerName = jsonlite::unbox( c(id)), tasks = "")
    configJson <- jsonlite::toJSON(body, pretty = TRUE)
  }
  else{
    config <- jsonlite::fromJSON(paste0(getwd(), "/", ".session.json"))
    config$sessionIds <- c(config$sessionIds, id)
    configJson <- jsonlite::toJSON(config, pretty = TRUE)
  }

  print("Your cluster is being provisioned...")

  write(configJson, file=".session.json")
}

az_start_session_with_config <- function(configPath){
  config <- jsonlite::fromJSON(configPath)
  credentials <- get_batch_credentials(configPath)

  requestDate <- format(Sys.time(), "%Y%b%d%H%M%S", tz="GMT")

  id <- sprintf("%s-%s-%s",
                "pysduck",
                credentials$name,
                requestDate)

  headers <- c()
  headers['content-type'] <- 'application/json;odata=minimalmetadata'

  commands <- c("cd /",
                "cd etc/R",
                "echo \"options(repos = list(CRAN=\\\"http://cran.us.r-project.org/\\\"))\" >> Rprofile.site")

  body = list(vmSize = config$vmSize,
              id = id,
              targetDedicated = config$numberOfNodes,
              startTask = list(
                commandLine = linux_wrap_commands(commands),
                runElevated = TRUE,
                environmentSettings = list(list(
                  name = "REPOS",
                  value ="http://cran.us.r-project.org"))
              ),
              virtualMachineConfiguration=list(imageReference=list(publisher="microsoft-ads", offer="linux-data-science-vm", sku="linuxdsvm", version="latest"),
                                               nodeAgentSKUId="batch.node.centos 7"))

  size <- nchar(jsonlite::toJSON(body, method="C", auto_unbox = TRUE))
  headers['Content-Length'] <- size

  request <- AzureRequest$new(
    method = "POST",
    path = "/pools",
    query = list("api-version" = apiVersion),
    headers = headers
  )

  commands <- c("cd /",
                "cd usr/lib/R/site-library/littler/examples",
                "export REPOS=http://cran.us.r-project.org",
                get_installation_command())

  body = list(id=id,
              poolInfo=list("poolId"=id),
              jobPreparationTask = list(
                commandLine = linux_wrap_commands(commands),
                runElevated = TRUE,
                environmentSettings = list(list(
                  name = "REPOS",
                  value="http://cran.us.r-project.org"))
              ))

  size <- nchar(jsonlite::toJSON(body, method="C", auto_unbox = TRUE))

  headers['Content-Length'] <- size

  request <- AzureRequest$new(
    method = "POST",
    path = "/jobs",
    query = list("api-version" = apiVersion),
    headers = headers
  )

  CallBatchService(request, credentials, body)

  print("Your cluster is being provisioned...")

  config <- jsonlite::fromJSON(file = configPath, auto_unbox = TRUE)
  config$clusterIds <- c(config$clusterIds, id)
  configJson <- jsonlite::toJSON(config, auto_unbox = TRUE, pretty = TRUE)
  write(configJson, file="az_config.json")
}

az_stop_session <- function(poolId = ""){
  headers <- c()
  headers['Content-Length'] <- 0
  headers['Content-Type'] <- 'application/json;odata=minimalmetadata'

  if(poolId == ""){
    config <- jsonlite::fromJSON(txt = ".session.json")
    poolId <- config$sessionIds[1]
  }

  credentials <- get_batch_credentials()

  request <- AzureRequest$new(
    method = "DELETE",
    path = paste0("/pools/", poolId),
    query = list("api-version" = apiVersion),
    headers = headers
  )

  CallBatchService(request, credentials)

  print("Your session has ended, and your cluster is being shut down...")

  file <- paste0(getwd(), "/", ".session.json")

  if(file.exists(file)) file.remove(file)
}

get_session_file <- function(){
  config <- jsonlite::fromJSON(paste0(getwd(), "/", ".session.json"))
}


az_run_model <- function(modelId, pathToModel = getwd(), parameters=list()){
  batchCredentials <- GetBatchCredentials()
  storageCredentials <- GetStorageCredentials()()
  session <- get_session_file()

  filePath <- strsplit(pathToModel, "/")
  filePath <- unlist(filePath)

  if(length(filePath) == 1){
    settings <- get_configuration_file()
    pathToModel <- paste0(settings$rootDirectory, "/", pathToModel)
  }

  if(modelId %in% session$tasks){
    stop(paste0("There's already a task with the model ", modelId, ". Please use another model name"))
  }

  upload_data(session$containerName, pathToModel)
  filePath <- strsplit(pathToModel, "/")
  filePath <- unlist(filePath)
  lastWord <- filePath[length(filePath)]

  commandLine = paste("Rscript --vanilla", lastWord, paste(parameters, collapse = " "), collapse = " ")

  modelResourceFile <-list(
    blobSource=sprintf("https://%s.blob.core.windows.net/%s/%s", storageCredentials$name, session$containerName, lastWord),
    filePath=lastWord
  )

  body = list(id=modelId,
              commandLine=commandLine,
              resourceFiles=list(modelResourceFile))

  size <- nchar(rjson::toJSON(body, method="C"))

  headers <- c()
  headers['Content-Length'] <- size
  headers['Content-Type'] <- "application/json;odata=minimalmetadata"

  response <- batch_request("POST", paste0("/jobs/", session$sessionIds[1], "/tasks"), batchCredentials, headers, body)

  if(length(session$tasks) == 1 && session$tasks == ""){
    session$tasks <- c(modelId)
  }
  else{
    session$tasks <- c(session$tasks, modelId)
  }

  configJson <- jsonlite::toJSON(session, pretty = TRUE)
  write(configJson, file=".session.json")

  print(paste0("Your model ", modelId, " has been created."))
}

az_run_models <- function(jobId, models, dataset, commandLine="", parameters=list(), containerName){
  total <- length(models)

  batchCredentials <- GetBatchCredentials()
  storageCredentials <- GetStorageCredentials()()

  for(i in 1:total){
    commandLine = paste("Rscript --vanilla", models[i], paste(parameters, collapse = " "), collapse = " ")

    datasetResourceFile <-list(
      blobSource=sprintf("https://%s.blob.core.windows.net/%s/%s", storageCredentials$name, containerName, dataset),
      filePath=dataset
    )

    modelResourceFile <-list(
      blobSource=sprintf("https://%s.blob.core.windows.net/%s/%s", storageCredentials$name, containerName, models[i]),
      filePath=models[i]
    )

    body = list(id=paste0("Task-",i),
                commandLine=commandLine,
                resourceFiles=list(datasetResourceFile, modelResourceFile))

    size <- nchar(rjson::toJSON(body, method="C"))

    headers <- c()
    headers['Content-Length'] <- size
    headers['Content-Type'] <- "application/json;odata=minimalmetadata"

    batch_request("POST", paste0("/jobs/", jobId, "/tasks"), batchCredentials, headers, body)
  }
}

az_list_nodes <- function(poolid = "", raw = FALSE){
  batchCredentials <- GetBatchCredentials()

  if(poolid == ""){
    config <- rjson::fromJSON(file = paste0(getwd(), "/", ".session.json"))
    poolid <- config$sessionIds[[1]]
  }

  request <- AzureRequest$new(
    method = "GET",
    path = paste0("/pools/", poolid, "/nodes"),
    query = list("api-version" = apiVersion),
    headers = headers
  )

  nodes <- CallBatchService(request, batchCredentials, body)

  if(length(nodes$value) > 0){
    for(i in 1:length(nodes$value)){
      print(sprintf("Node: %s - %s - %s", nodes$value[[i]]$id, nodes$value[[i]]$state, nodes$value[[i]]$ipAddress))
    }
  }
  else{
    print("There are currently no nodes in the pool.")
  }

  if(raw){
    nodes
  }
}

az_list_models <- function(raw = FALSE){
  config <- rjson::fromJSON(file = paste0(getwd(), "/", ".session.json"))
  sessionId <- config$sessionIds[[1]]
  batchCredentials <- GetBatchCredentials()

  request <- AzureRequest$new(
    method = "GET",
    path = paste0("/jobs/", sessionId, "/tasks"),
    query = list("api-version" = apiVersion),
    headers = headers
  )

  tasks <- CallBatchService(request, batchCredentials, body)

  if(length(tasks$value) > 0){
    for(i in 1:length(tasks$value)){
      print(sprintf("%s - %s - %s", tasks$value[[i]]$id, tasks$value[[i]]$state, tasks$value[[i]]$commandLine))
    }
  }

  if(raw){
    tasks
  }
}

az_list_model_files <- function(modelName){
  config <- rjson::fromJSON(file = paste0(getwd(), "/", ".session.json"))
  sessionId <- config$sessionIds[[1]]
  batchCredentials <- GetBatchCredentials()

  batch_request("GET", paste0("/jobs/", sessionId, "/tasks/", modelName, "/files"), batchCredentials)

  request <- AzureRequest$new(
    method = "GET",
    path = paste0("/jobs/", sessionId, "/tasks/", modelName, "/files"),
    query = list("api-version" = apiVersion),
    headers = headers
  )

  CallBatchService(request, batchCredentials)
}

az_add_node <- function(numOfNodes){
  batchCredentials <- GetBatchCredentials()

  config <- rjson::fromJSON(file = ".session.json")
  sessionId <- config$sessionIds[1]

  pool <- get_pool()
  totalCores <- pool$targetDedicated + numOfNodes

  body <- list("targetDedicated" = totalCores)
  size <- nchar(jsonlite::toJSON(body, method="C", auto_unbox = TRUE))

  headers <- c()
  headers['Content-Type'] <- 'application/json;odata=minimalmetadata'
  headers['Content-Length'] <- size

  request <- AzureRequest$new(
    method = "POST",
    path = paste0("/pools/", sessionId, "/resize"),
    query = list("api-version" = apiVersion),
    headers = headers
  )

  CallBatchService(request, batchCredentials, body)
}

az_get_result <- function(modelId, filePath = "stdout.txt"){
  config <- rjson::fromJSON(file = ".session.json")
  sessionId <- config$sessionIds[1]

  batchCredentials = GetBatchCredentials()
  temp <- filePath

  filePath <- strsplit(filePath, "/")
  filePath <- unlist(filePath)
  lastWord <- filePath[length(filePath)]

  batch_request_download("GET", paste0("/jobs/", sessionId, "/tasks/", modelId, "/files/", temp), batchCredentials, filePath=lastWord)
}

az_get_results <- function(modelIds, filePath = "stdout.txt"){
  config <- rjson::fromJSON(file = ".session.json")
  sessionId <- config$sessionIds[1]

  batchCredentials = GetBatchCredentials()
  temp <- filePath

  filePath <- strsplit(filePath, "/")
  filePath <- unlist(filePath)
  lastWord <- filePath[length(filePath)]

  batch_request_download("GET", paste0("/jobs/", sessionId, "/tasks/", modelId, "/files/", temp), batchCredentials, filePath=lastWord)
}
